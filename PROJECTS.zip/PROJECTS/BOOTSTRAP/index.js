// tomorrow's problems 

// difference between charAt() and charCodeAt() 
// this code

 <script>
function f1(){
var values = [10, "A", true];
values[3]="John";
document.write(values[0] + "<br>" +
values[1]);
}
f1();
</script>


// one stopwatch problem 
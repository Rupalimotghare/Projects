
let r = [{
    city: "pune",
    name: "Pruthvi",
    age: 24.3
}, {
    city: "latur",
    name: "ananta",
    age: 22.7
}
    , {
    city: "mumbai",
    name: "sohel",
    age: 23.5
}]
var newArr = [r[0].age, r[1].age, r[2].age];

// console.log(newArr)
console.log(newArr.sort((a, b) => {
    return a - b;

}))